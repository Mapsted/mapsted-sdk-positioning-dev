//
//  MNUserLocationManager.h
//  nav
//
//  Created by Tianyun Shan on 2017-01-30.
//  Copyright © 2017 Maspted. All rights reserved.
//

#ifndef MNLocationManager_h
#define MNLocationManager_h

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import "MNGPSLoc.h"
#import "LocationServicesCallback.h"

@interface MNUserLocationManager : NSObject<CLLocationManagerDelegate>

@property MNGPSLoc* currentLoc;
@property NSMutableArray* cachedLocs;
@property (nonatomic) CLLocationManager *mLocationManager;
@property NSMutableArray *regions;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil;
- (void)showBackgroundLocationUpdates:(BOOL)show;
-(BOOL)isLocationServiceRunning;
- (void) start;
- (void) stop;

- (void) startListeningBle: (NSMutableArray *) proximityUUIDs;
- (void) stopListeningBle;

- (BOOL)isBetterLocation: (MNGPSLoc *)location comparedWith:(MNGPSLoc *)currentBestLoc;
@end

#endif /* MNUserLocationManager_h */
