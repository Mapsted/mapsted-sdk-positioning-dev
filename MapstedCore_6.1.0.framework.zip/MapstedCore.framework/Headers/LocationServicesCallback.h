//
//  LocationServicesCallback.h
//  positioning
//
//  Created by Parth Bhatt on 24/09/24.
//  Copyright © 2024 Mapsted. All rights reserved.
//

#ifndef LocationServicesCallback_h
#define LocationServicesCallback_h

// MyCustomDelegate.h

@protocol LocationServicesCallback <NSObject>

// This method is optional and can be implemented by the delegate.
@required
- (void)onLocationServicesSuccess;

// This method is required and must be implemented by the delegate.
@optional
- (void)didFailWithError:(NSError *)error;

@end



#endif /* LocationServicesCallback_h */
