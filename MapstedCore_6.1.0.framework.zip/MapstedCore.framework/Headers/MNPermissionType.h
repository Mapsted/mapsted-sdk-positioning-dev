//
//  MNPermissionType.h
//  positioning
//
//  Created by Parth Bhatt on 25/10/24.
//  Copyright © 2024 Mapsted. All rights reserved.
//

#ifndef MNPermissionType_h
#define MNPermissionType_h

typedef NS_ENUM(NSInteger, MNPermissionType) {
  MNPermissionTypeLocation = 0,
  MNPermissionTypeBluetooth = 1,
  MNPermissionTypeNotifications = 2,
  MNPermissionTypeMotionAndFitness = 3
};


#endif /* MNPermissionType_h */
